-- MULA PARTY 1.0 — ejecutar en Supabase > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.parties (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  title text not null,
  admin_pin_hash text not null,
  status text not null default 'open' check (status in ('open','closed')),
  created_at timestamptz not null default now(),
  closed_at timestamptz
);

create table if not exists public.members (
  id uuid primary key default gen_random_uuid(),
  party_id uuid not null references public.parties(id) on delete cascade,
  name text not null,
  name_key text not null,
  pin_hash text not null,
  is_admin boolean not null default false,
  created_at timestamptz not null default now(),
  unique (party_id, name_key)
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  party_id uuid not null references public.parties(id) on delete cascade,
  member_id uuid not null references public.members(id) on delete restrict,
  product text not null,
  category text not null default 'Otros',
  amount numeric(14,2) not null check (amount > 0),
  created_at timestamptz not null default now()
);

create index if not exists members_party_idx on public.members(party_id);
create index if not exists expenses_party_idx on public.expenses(party_id, created_at);

-- El navegador nunca accede directamente a las tablas. Solo el servidor,
-- usando la clave service_role guardada como variable privada, puede hacerlo.
alter table public.parties enable row level security;
alter table public.members enable row level security;
alter table public.expenses enable row level security;
revoke all on public.parties, public.members, public.expenses from anon, authenticated;
