# MULA PARTY 1.0

Aplicación web adaptable a celulares para registrar gastos compartidos. Incluye juntadas con código único, PIN por participante, PIN del administrador, catálogo inicial, actualización periódica, liquidación y transferencias optimizadas, QR, cierre e historial persistente en Supabase.

## Importante
Este paquete es el código fuente de la primera versión desplegable. **Todavía no está publicado ni conectado a una base de datos real.** Para activarlo hace falta crear un proyecto Supabase y un servicio de hosting, configurar secretos y desplegarlo. No compartas la clave `service_role` con participantes ni la publiques en el navegador.

## 1. Crear la base de datos
1. Crear un proyecto en https://supabase.com.
2. Abrir SQL Editor.
3. Ejecutar el contenido completo de `supabase/schema.sql`.
4. En Project Settings > API, copiar Project URL y `service_role` secret. La clave `service_role` es privada y va solamente en el servidor.

## 2. Configurar y ejecutar
Requiere Node.js 20 o superior.

```bash
cp .env.example .env
# Editar .env con SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY y SESSION_SECRET
npm install
npm start
```

Abrir http://localhost:3000.

`SESSION_SECRET` debe ser una cadena aleatoria de al menos 32 caracteres. Ejemplo para generarla localmente: `openssl rand -hex 32`.

## 3. Publicar
Desplegar este repositorio como servicio Node en Render, Railway u otro hosting compatible. Configurar las variables del archivo `.env` en el panel privado del hosting. Usar HTTPS. En Render, crear un Web Service con Build Command `npm install` y Start Command `npm start`.

## Cómo se usa
- El organizador crea una juntada, ingresa su nombre y define su PIN de administrador.
- La app genera un código `MP-XXXXXX`.
- Los amigos abren el enlace o escanean el QR, ingresan código, nombre y PIN personal.
- Cada participante puede agregar gastos y ver el estado actualizado cada cinco segundos.
- Solo el administrador puede eliminar gastos o cerrar la juntada.
- El cierre conserva los datos en Supabase. Para consultar una juntada cerrada, se ingresa nuevamente con su código, nombre y PIN; no se pueden añadir gastos.

## Seguridad y límites de esta primera versión
- Los PIN se almacenan con hash bcrypt; no se guardan en texto plano.
- El navegador no recibe la clave privada de Supabase. Las tablas tienen RLS activado y acceso directo revocado para `anon` y `authenticated`.
- Los endpoints tienen límite básico de solicitudes.
- Los gastos se expresan en pesos argentinos y admiten centavos.
- La sincronización usa consulta periódica cada cinco segundos, no WebSockets.
- No incluye recuperación de PIN: si se pierde, el administrador puede eliminar la identidad y volver a invitarla en una futura herramienta de administración; para la primera versión, evitar perderlo.
- La liquidación optimiza la cantidad de transferencias, con pequeñas diferencias posibles por redondeo de centavos.
- El historial persistente está en la base de datos, pero esta versión inicial no incorpora todavía una pantalla de archivo con listado de todas las juntadas del administrador. Se puede agregar en la siguiente iteración.
- Antes de un uso amplio, conviene una revisión de seguridad y pruebas de carga.
