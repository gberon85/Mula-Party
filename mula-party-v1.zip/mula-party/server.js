require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const { rateLimit } = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const QRCode = require('qrcode');
const { createClient } = require('@supabase/supabase-js');
const path = require('path');

const required = ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'SESSION_SECRET'];
for (const key of required) if (!process.env[key]) { console.error(`Falta configurar ${key}`); process.exit(1); }
if (process.env.SESSION_SECRET.length < 32) { console.error('SESSION_SECRET debe tener al menos 32 caracteres.'); process.exit(1); }
const db = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '30kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 180, standardHeaders: 'draft-8', legacyHeaders: false }));
app.use('/api/auth/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 25, standardHeaders: 'draft-8', legacyHeaders: false }));

const clean = (s, max=80) => String(s ?? '').trim().replace(/[<>\u0000-\u001f]/g, '').slice(0,max);
const pinOk = p => /^\d{4,8}$/.test(String(p ?? ''));
const codeGen = () => 'MP-' + Math.random().toString(36).slice(2,8).toUpperCase();
const sign = payload => jwt.sign(payload, process.env.SESSION_SECRET, { expiresIn: '14d', issuer: 'mula-party' });
function auth(req,res,next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i,'');
  try { req.session = jwt.verify(token, process.env.SESSION_SECRET, { issuer: 'mula-party' }); next(); }
  catch { res.status(401).json({ error: 'Tu sesión venció. Volvé a ingresar.' }); }
}
async function snapshot(partyId) {
  const [{data:party,error:pe},{data:members,error:me},{data:expenses,error:ee}] = await Promise.all([
    db.from('parties').select('id,code,title,status,created_at,closed_at').eq('id',partyId).single(),
    db.from('members').select('id,name,is_admin,created_at').eq('party_id',partyId).order('created_at'),
    db.from('expenses').select('id,member_id,product,category,amount,created_at').eq('party_id',partyId).order('created_at')
  ]);
  if (pe || me || ee) throw new Error('No se pudo leer la juntada.');
  return { party, members, expenses };
}
app.post('/api/party/create', async (req,res) => {
  try {
    const title=clean(req.body.title,70), name=clean(req.body.name,40), pin=String(req.body.pin||'');
    if (!title || !name || !pinOk(pin)) return res.status(400).json({error:'Completá el nombre de la juntada, tu nombre y un PIN de 4 a 8 números.'});
    let code, party, error;
    for(let i=0;i<5;i++) { code=codeGen(); const r=await db.from('parties').insert({code,title,admin_pin_hash:await bcrypt.hash(pin,12)}).select().single(); party=r.data; error=r.error; if(!error) break; }
    if(error || !party) throw new Error('No se pudo crear el código. Intentá nuevamente.');
    const m=await db.from('members').insert({party_id:party.id,name,name_key:name.toLocaleLowerCase('es-AR'),pin_hash:await bcrypt.hash(pin,12),is_admin:true}).select().single();
    if(m.error) { await db.from('parties').delete().eq('id',party.id); throw m.error; }
    const token=sign({partyId:party.id,memberId:m.data.id,isAdmin:true});
    res.json({token,...await snapshot(party.id),me:{id:m.data.id,isAdmin:true}});
  } catch(e) { console.error(e); res.status(500).json({error:'No se pudo crear la juntada.'}); }
});
app.post('/api/auth/join', async (req,res) => {
  try {
    const code=clean(req.body.code,12).toUpperCase(), name=clean(req.body.name,40), pin=String(req.body.pin||'');
    if(!code || !name || !pinOk(pin)) return res.status(400).json({error:'Revisá el código, el nombre y el PIN (4 a 8 números).'});
    const {data:party,error}=await db.from('parties').select('*').eq('code',code).single();
    if(error || !party) return res.status(404).json({error:'No encontramos esa juntada. Revisá el código.'});
    const key=name.toLocaleLowerCase('es-AR');
    let {data:member}=await db.from('members').select('*').eq('party_id',party.id).eq('name_key',key).maybeSingle();
    if(member) {
      if(!await bcrypt.compare(pin,member.pin_hash)) return res.status(401).json({error:'Ese nombre ya está registrado. El PIN no coincide.'});
    } else {
      if(party.status!=='open') return res.status(403).json({error:'Esta juntada está cerrada y ese participante no está registrado.'});
      const ins=await db.from('members').insert({party_id:party.id,name,name_key:key,pin_hash:await bcrypt.hash(pin,12)}).select().single();
      if(ins.error) return res.status(409).json({error:'No se pudo registrar ese nombre. Probá nuevamente.'});
      member=ins.data;
    }
    const token=sign({partyId:party.id,memberId:member.id,isAdmin:member.is_admin});
    res.json({token,...await snapshot(party.id),me:{id:member.id,isAdmin:member.is_admin}});
  } catch(e) { console.error(e); res.status(500).json({error:'No se pudo ingresar a la juntada.'}); }
});
app.get('/api/party', auth, async (req,res) => {
  try { res.json({...await snapshot(req.session.partyId),me:{id:req.session.memberId,isAdmin:req.session.isAdmin}}); }
  catch(e) { res.status(500).json({error:e.message}); }
});
app.post('/api/expenses', auth, async (req,res) => {
  try {
    const product=clean(req.body.product,60), category=clean(req.body.category,30)||'Otros', amount=Number(req.body.amount);
    if(!product || !Number.isFinite(amount) || amount<=0 || amount>1000000000) return res.status(400).json({error:'Ingresá un producto y un importe válido.'});
    const {data:party}=await db.from('parties').select('status').eq('id',req.session.partyId).single();
    if(!party || party.status!=='open') return res.status(403).json({error:'La juntada está cerrada.'});
    const {error}=await db.from('expenses').insert({party_id:req.session.partyId,member_id:req.session.memberId,product,category,amount:Number(amount.toFixed(2))});
    if(error) throw error;
    res.json(await snapshot(req.session.partyId));
  } catch(e) { console.error(e); res.status(500).json({error:'No se pudo guardar el gasto.'}); }
});
app.delete('/api/expenses/:id', auth, async (req,res) => {
  if(!req.session.isAdmin) return res.status(403).json({error:'Solo el administrador puede eliminar gastos.'});
  try { const {error}=await db.from('expenses').delete().eq('id',req.params.id).eq('party_id',req.session.partyId); if(error) throw error; res.json(await snapshot(req.session.partyId)); }
  catch(e) { res.status(500).json({error:'No se pudo eliminar el gasto.'}); }
});
app.post('/api/party/close', auth, async (req,res) => {
  if(!req.session.isAdmin) return res.status(403).json({error:'Solo el administrador puede cerrar la juntada.'});
  try { const {error}=await db.from('parties').update({status:'closed',closed_at:new Date().toISOString()}).eq('id',req.session.partyId).eq('status','open'); if(error) throw error; res.json(await snapshot(req.session.partyId)); }
  catch(e) { res.status(500).json({error:'No se pudo cerrar la juntada.'}); }
});
app.get('/api/qr', async (req,res) => {
  try { const url=String(req.query.url||''); if(!url.startsWith('http') || url.length>500) return res.status(400).end(); const png=await QRCode.toBuffer(url,{width:320,margin:2}); res.type('png').send(png); }
  catch { res.status(400).end(); }
});
app.get('*path', (req,res) => res.sendFile(path.join(__dirname,'public','index.html')));
const port=Number(process.env.PORT)||3000;
app.listen(port,()=>console.log(`MULA PARTY activo en puerto ${port}`));
